﻿using Microsoft.AspNetCore.SignalR;

namespace SignalRSample.Hubs
{
    public class OrderHub : Hub
    {
    }
}
